# ARIA Prototype - AI Chatbot  
This is a simple AI-powered chatbot using Gemini API with Flask.  
## How to Run  
1. Install dependencies: