import os
import requests
from flask import Flask, render_template, request
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Load Gemini API Key from .env
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Function to interact with Gemini API
def get_gemini_response(user_input):
    url = "https://api.gemini.com/chat"
    headers = {"Authorization": f"Bearer {GEMINI_API_KEY}"}
    data = {"message": user_input}

    try:
        response = requests.post(url, headers=headers, json=data)
        return response.json().get("response", "Sorry, I couldn't process that.")
    except Exception as e:
        return f"Error: {str(e)}"

@app.route("/", methods=["GET", "POST"])
def index():
    bot_response = ""
    if request.method == "POST":
        user_input = request.form.get("user_input")
        bot_response = get_gemini_response(user_input)
    return render_template("index.html", bot_response=bot_response)

if __name__ == "__main__":
    app.run(debug=True)